/*
 * Tran Hai Vong Thang 40004591
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		char userChoice = 'i';
		Heap minHeap = new Heap<Integer>(15);
		PriorityQueue pq = new PriorityQueue<String>(10);
		System.out.println("Testing the PriorityQueue class:");
		while (userChoice == 'i' || userChoice == 'r' || userChoice == 'm') {
			System.out.println("What do you want to do? ('i' to Insert node, 'r' to remove node with smallest key, " +
					"'m' to return the node with smallest key without removing it, 'q' or anything else to quit)");
			Scanner sc = new Scanner(System.in);
			userChoice = sc.next().charAt(0);
			System.out.println(userChoice);

			switch (userChoice) {
				case 'i':
					int userInput;
					try {
						userInput = (int) userInputInt();
						minHeap.insert(userInputInt());
					} catch (InputMismatchException error) {
					}
					break;
				case 'r':
					System.out.println("Removed the element with smallest key " + pq.remove() + ".");
					break;
				case 'm': System.out.println("The element with the smallest key is: " + minHeap.min());
					break;
				default:
					System.out.println("Quitting the priority queue test. The priority queue is now:");
					pq.print();
					userChoice = 'q';
			}
		}

		System.out.println("Testing the Heap class:");
		boolean addNumber = true;
		try {
			while(addNumber) {
				minHeap.insert(userInputInt());
			}
		}catch(InputMismatchException error) {
			addNumber = false;
		}
		minHeap.printHeap();
		System.out.println("The element with the smallest key is: " + minHeap.min());
	}

    private static int userInputInt() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a number to add to the heap or a letter if finished adding.");
        Integer key = scan.nextInt();
        scan.close();
        return key;
    }
	/*
	private static String userInput() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number to add to the heap or a letter if finished adding.");
		Integer key = scan.nextInt();
		scan.close();
		return key;
	}*/
}
